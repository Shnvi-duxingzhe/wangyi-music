/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="swiper_angular" />
export * from './swiper-angular';
